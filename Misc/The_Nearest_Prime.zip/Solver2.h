#pragma once

int GetNearestPrime2(int number);