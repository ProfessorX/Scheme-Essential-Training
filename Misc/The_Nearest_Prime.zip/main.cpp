#include <array>
#include <cmath>
#include <chrono>
#include <iostream>
#include <iomanip>
#include <random>
#include "garbageMan.h"
#include "Solver1.h"
#include "Solver2.h"
#include "Solver3.h"

int get_nearest_eager(int x);

using namespace std;

int main(void)
{
    const int UpperBoundIncluded = 1000000;
    random_device rd;
    default_random_engine eg(rd());
    uniform_int_distribution<int> range(1, UpperBoundIncluded - 10);
    
    const int Attemps = 50000;
    array<int, Attemps> questions;
    for (int i = 0; i < Attemps; i++) {
        questions[i] = range(eg);
    }

    int i;
    chrono::system_clock::time_point start;
    chrono::system_clock::duration elapsed;

    array<int, Attemps> result1;
    i = 0;
    start = chrono::high_resolution_clock::now();
    for (auto n : questions) {
        result1[i++] = get_nearest(n);
    }
    elapsed = chrono::high_resolution_clock::now() - start;
    cout << "Elapsed : " << elapsed.count() << "ms" << endl;

    array<int, Attemps> result2;
    i = 0;
    start = chrono::high_resolution_clock::now();
    Solver1<UpperBoundIncluded> solver1;
    for (auto n : questions) {
        result2[i++] = solver1.GetNearestPrime(n);
    }
    elapsed = chrono::high_resolution_clock::now() - start;
    cout << "Elapsed : " << elapsed.count() << "ms" << endl;

    array<int, Attemps> result3;
    i = 0;
    start = chrono::high_resolution_clock::now();
    for (auto n : questions) {
        result3[i++] = GetNearestPrime2(n);
    }
    elapsed = chrono::high_resolution_clock::now() - start;
    cout << "Elapsed : " << elapsed.count() << "ms" << endl;

    array<int, Attemps> result4;
    i = 0;
    start = chrono::high_resolution_clock::now();
    Solver3<UpperBoundIncluded> solver3;
    for (auto n : questions) {
        result4[i++] = solver3.GetNearestPrime(n);
    }
    elapsed = chrono::high_resolution_clock::now() - start;
    cout << "Elapsed : " << elapsed.count() << "ms" << endl;

    /*for (int i = 0; i < 1000; i++) {
        cout << setw(5) << questions[i] << " ";
        if ((i + 1) % 10 == 0) {
            cout << endl;
        }
    }
    cout << endl;*/

    int max_width = log10(UpperBoundIncluded);
    for (i = 0; i < Attemps; i++) {
        if (result1[i] != result2[i]
            || result1[i] != result3[i]
            || result1[i] != result4[i]) {
            cout << "Questing " << setw(max_width) << questions[i] << ", "
                << "but answer NOT equal : "
                << setw(max_width) << result1[i] << " "
                << setw(max_width) << result2[i] << " "
                << setw(max_width) << result3[i] << " "
                << setw(max_width) << result4[i]
                << endl;
        }
    }

    return 0;
}
