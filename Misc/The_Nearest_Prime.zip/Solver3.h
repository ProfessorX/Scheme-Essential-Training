#pragma once

#include <array>
#include <vector>
#include <list>
#include <cmath>
#include <algorithm>
#include <bitset>

template<int UpperBoundIncluded>
class Solver3
{
public:
    int GetNearestPrime(int number)
    {
        auto it = std::upper_bound(
            PRIME_TABLE.begin(),
            PRIME_TABLE.end(),
            number);
        if (it == PRIME_TABLE.end()) {
            return PRIME_TABLE.back();
        } else if (it == PRIME_TABLE.begin()) {
            return *it;
        } else {
            int a = *(it - 1), b = *it;
            return (b - number) > (number - a) ? a : b;
        }
    }
private:
    std::vector<int> PRIME_TABLE;
public:
    Solver3(void)
    {
        bitset<UpperBoundIncluded + 1> isPrimeFlags;
        for (int x = 1; x <= sqrt(UpperBoundIncluded); x++) {
            for (int y = 1; y <= sqrt(UpperBoundIncluded); y++) {
                int n = 4 * x * x + y * y;
                if (n <= UpperBoundIncluded && (n % 12 == 1 || n % 12 == 5)) {
                    isPrimeFlags.flip(n);
                }
                n = 3 * x * x + y * y;
                if (n <= UpperBoundIncluded && (n % 12 == 7)) {
                    isPrimeFlags.flip(n);
                }
                n = 3 * x * x - y * y;
                if (x > y && n <= UpperBoundIncluded && (n % 12 == 11)) {
                    isPrimeFlags.flip(n);
                }
            }
        }

        for (int n = 5; n <= sqrt(UpperBoundIncluded); n++) {
            if (isPrimeFlags[n]) {
                int nn = n * n;
                for (int k = nn; k <= UpperBoundIncluded; k += nn) {
                    isPrimeFlags[k] = false;
                }
            }
        }

        PRIME_TABLE.reserve(2 + isPrimeFlags.count());

        PRIME_TABLE.push_back(2);
        PRIME_TABLE.push_back(3);
        for (int i = 5; i <= UpperBoundIncluded; i += 2) {
            if (isPrimeFlags[i]) {
                PRIME_TABLE.push_back(i);
            }
        }
    }
};