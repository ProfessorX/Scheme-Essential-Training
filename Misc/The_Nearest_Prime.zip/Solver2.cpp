#include "Solver2.h"

#include <array>
#include <cmath>

static bool RabinMillerPrimalityTest(int n);
static int ModularPow(int base, int exponent, int modulus);

int GetNearestPrime2(int number)
{
    for (int step = 0, sign = -1;
        !RabinMillerPrimalityTest(number);
        sign = -sign, step++
        ) {
        number += sign * step;
    }

    return number;
}

bool RabinMillerPrimalityTest(int n)
{
    if (n == 2) return true;
    if (n <= 1 || (n & 1) == 0) return false;

    int s = 0, d = n - 1;
    while (d >>= 1) {
        s++;
        if (d & 1) break;
    }
    d = (n - 1) / (1 << s);

    const std::array<int, 3> VerifiedA = { 2, 7, 61 };
    if (n == 7 || n == 61) return true;
    for (int a : VerifiedA) {
        long long x = ModularPow(a, d, n);
        if (x == 1 || x == n - 1) continue;
        for (int j = 0; j < s; j++) {
            x = (x * x) % n;
            if (x == 1) return false;
            if (x == n - 1) goto NEXT_LOOP;
        }
        return false;
NEXT_LOOP:
        ;
    }
    return true;
}

int ModularPow(int base, int exponent, int modulus)
{
    long long b = base;
    int result = 1;
    while (exponent) {
        if (exponent & 1) {
            result = (result * b) % modulus;
        }
        exponent >>= 1;
        b = (b * b) % modulus;
    }
    return result;
}