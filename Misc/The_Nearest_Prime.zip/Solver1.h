#pragma once

#include <vector>
#include <cmath>

using namespace std;

template<int UpperBoundIncluded>
class Solver1
{
public:
    int GetNearestPrime(int number)
    {
        for (int step = 0, sign = -1;
            !IsPrime(number);
            sign = -sign, step++
            ) {
            number += sign * step;
        }

        return number;
    }
private:
    vector<int> PRIME_TABLE;
    bool IsPrime(int number)
    {
        if (number == 2) return true;
        if (number <= 1 || (number & 1) == 0) return false;

        for (int p : PRIME_TABLE) {
            if (number % p == 0) {
                return false;
            }
            if (p * p > number) {
                break;
            }
        }
        return true;
    }
public:
    Solver1(void) : PRIME_TABLE({ 2, 3, 5, 7, 11, 13, 17, 19 })
    {
        for (int i = 23; i <= sqrt(UpperBoundIncluded); i += 2) {
            if (IsPrime(i)) {
                PRIME_TABLE.push_back(i);
            }
        }
    }
};