#pragma once

typedef
struct prime_list
{
    unsigned prime;
    struct prime_list * next;
}
Node;

int get_nearest(int);